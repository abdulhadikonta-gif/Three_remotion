import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
// Needed for WebGL/Three.js rendering in headless Chrome
Config.setChromiumOpenGlRenderer('angle');
