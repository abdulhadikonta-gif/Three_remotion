import {Composition} from 'remotion';
import {Main} from './Main';

export const FPS = 30;
export const DURATION = 6 * FPS;

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={DURATION}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
