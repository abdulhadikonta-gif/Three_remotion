import {ThreeCanvas} from '@remotion/three';
import {useCurrentFrame, useVideoConfig, interpolate} from 'remotion';

// All animation is driven by the frame number (never useFrame/clock),
// so every render is deterministic.
export const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height, durationInFrames} = useVideoConfig();

  const rotY = frame * 0.04;
  const rotX = frame * 0.02;
  const scale = interpolate(frame, [0, 30], [0, 1], {extrapolateRight: 'clamp'});
  const bob = Math.sin(frame / 15) * 0.3;

  return (
    <ThreeCanvas width={width} height={height} camera={{position: [0, 0, 6], fov: 45}}>
      <color attach="background" args={['#0b0b1a']} />
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 5, 5]} intensity={2} />
      <mesh rotation={[rotX, rotY, 0]} position={[0, bob, 0]} scale={scale}>
        <torusKnotGeometry args={[1.2, 0.4, 200, 32]} />
        <meshStandardMaterial color="#7c5cff" metalness={0.5} roughness={0.25} />
      </mesh>
      <mesh position={[0, -2.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#14142b" />
      </mesh>
    </ThreeCanvas>
  );
};
