import {createTikTokStyleCaptions} from '@remotion/captions';
import {AbsoluteFill, Sequence, useVideoConfig} from 'remotion';
import {captions} from './captions';

// Groups words into short "pages" and highlights the active word.
export const Captions: React.FC = () => {
  const {fps} = useVideoConfig();
  const {pages} = createTikTokStyleCaptions({
    captions,
    combineTokensWithinMilliseconds: 1200,
  });

  return (
    <AbsoluteFill>
      {pages.map((page, i) => {
        const next = pages[i + 1] ?? null;
        const from = (page.startMs / 1000) * fps;
        const end = next ? (next.startMs / 1000) * fps : from + 2 * fps;
        const duration = Math.max(1, Math.round(end - from));
        return (
          <Sequence key={i} from={Math.round(from)} durationInFrames={duration}>
            <CaptionPage page={page} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

import {useCurrentFrame} from 'remotion';
import type {TikTokPage} from '@remotion/captions';

const CaptionPage: React.FC<{page: TikTokPage}> = ({page}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nowMs = page.startMs + (frame / fps) * 1000;

  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 140}}>
      <div style={{fontSize: 80, fontWeight: 800, fontFamily: 'sans-serif', whiteSpace: 'pre'}}>
        {page.tokens.map((t) => {
          const active = t.fromMs <= nowMs && t.toMs > nowMs;
          return (
            <span key={t.fromMs} style={{color: active ? '#ffd24a' : '#ffffff', textShadow: '0 4px 16px #000'}}>
              {t.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
