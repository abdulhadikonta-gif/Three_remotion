import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {Scene} from './Scene';
import {Captions} from './Captions';

// Put your audio at public/audio.mp3 and set HAS_AUDIO to true.
const HAS_AUDIO = false;

export const Main: React.FC = () => (
  <AbsoluteFill>
    <Scene />
    <Captions />
    {HAS_AUDIO ? <Audio src={staticFile('audio.mp3')} /> : null}
  </AbsoluteFill>
);
