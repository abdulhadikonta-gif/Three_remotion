import type {Caption} from '@remotion/captions';

// Replace with real captions (e.g. from Whisper). Times are in milliseconds.
export const captions: Caption[] = [
  {text: 'Hello ', startMs: 300, endMs: 900, timestampMs: 600, confidence: null},
  {text: 'from ', startMs: 900, endMs: 1300, timestampMs: 1100, confidence: null},
  {text: 'Three.js ', startMs: 1300, endMs: 2200, timestampMs: 1750, confidence: null},
  {text: 'and ', startMs: 2200, endMs: 2600, timestampMs: 2400, confidence: null},
  {text: 'Remotion!', startMs: 2600, endMs: 3800, timestampMs: 3200, confidence: null},
];
