# Three.js + Remotion starter

1. Install Node.js 18+ (https://nodejs.org)
2. `npm install`
3. `npm run dev`     -> opens Remotion Studio (live preview)
4. `npm run render`  -> renders out/video.mp4

Files:
- src/Scene.tsx     3D scene (animate using useCurrentFrame)
- src/captions.ts   caption data (ms timings) - replace with your own / Whisper output
- src/Captions.tsx  caption styling
- src/Main.tsx      combines scene + captions + audio (drop audio.mp3 in public/, set HAS_AUDIO = true)
- src/Root.tsx      resolution, fps, duration
